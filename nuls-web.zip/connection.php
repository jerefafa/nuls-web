<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 05/03/2018
 * Time: 8:00 AM
 */
$conn =  new mysqli( "localhost", "nulsx10h_je", "Pithecus2013", "nulsx10h_nuls");
//$conn =  new mysqli( "localhost", "root"g, "", "new-nuls");