<?php
/**
 * Created by PhpStorm.
 * User: Joyce Balinquit
 * Date: 11/01/2019
 * Time: 8:40 AM
 */

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="CSS/Style4.css">
    <link type="text/css" rel="stylesheet" href="MaterializeCSS/materialize/css/materialize.min.css">
    <title>Receipt</title>
</head>
<body>


<page size ="A5">
    <div style = "margin-left: 3%; margin-right: 3%; padding-top: 5%;">
        <h3>National University<br>Learning Resource Center</h3>
        <p>
            551 M.F.Jhocson<br>
            St. Sampaloc<br>
            Manila, Metro Manila<br><br>
            05/03/018<br>
            <b>Casil, Dinaline Diaz</b><br>
            2015-102077<br><br>

            Today's Checkouts<br>
            -----------------------
            <br>
            Java: A beginner's guide<br>
            Barcode:<br>
            NULIB000006693<br>
            Due Dates:06/03/2018<br><br>
            Please return the book on the due date.

        </p><br><br>
    </div>
</page>

</body>
</html>
